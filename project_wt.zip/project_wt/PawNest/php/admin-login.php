<?php

require_once "db.php";


// Get login data
$email = $_POST["email"];
$password = $_POST["password"];


try {

    // Find admin using email
    $sql = "SELECT * FROM users
            WHERE email = :email
            AND role = 'admin'";

    $stmt = $conn->prepare($sql);

    $stmt->execute([
        ":email" => $email
    ]);

    $admin = $stmt->fetch(PDO::FETCH_ASSOC);


    // Check if admin exists
    if (!$admin) {

        die("Admin not found. Please check your email.");

    }


    // Check password
    if (password_verify($password, $admin["password"])) {

        echo "Admin login successful!";

        echo "<br><br>";

        echo '<a href="../admin/dashboard.html">Go to Admin Dashboard</a>';

    } else {

        die("Incorrect password.");

    }


} catch (PDOException $e) {

    die("Error during admin login: " . $e->getMessage());

}

?>
<?php

require_once "db.php";

// Get data from the form
$name = $_POST["name"];
$type = $_POST["type"];
$breed = $_POST["breed"];
$age = $_POST["age"];
$gender = $_POST["gender"];
$description = $_POST["description"];
$image = $_POST["image"];
$status = "Available";

try {

    // Insert pet into database
    $sql = "INSERT INTO pets
            (name, type, breed, age, gender, description, image, status)
            VALUES
            (:name, :type, :breed, :age, :gender, :description, :image, :status)";

    $stmt = $conn->prepare($sql);

    $stmt->execute([
        ":name" => $name,
        ":type" => $type,
        ":breed" => $breed,
        ":age" => $age,
        ":gender" => $gender,
        ":description" => $description,
        ":image" => $image,
        ":status" => $status
    ]);

    echo "Pet added successfully!";

} catch (PDOException $e) {

    echo "Error adding pet: " . $e->getMessage();

}

?>
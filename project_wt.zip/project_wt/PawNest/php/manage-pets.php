<?php

require_once "../php/db.php";

try {

    $sql = "SELECT * FROM pets ORDER BY id ASC";

    $stmt = $conn->prepare($sql);
    $stmt->execute();

    $pets = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    die("Error fetching pets: " . $e->getMessage());

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/style.css">

    <title>Manage Pets - PawNest</title>

</head>

<body>

    <!-- HEADER -->
    <header>

        <div class="logo">
            PawNest 🐾
        </div>

        <nav>
            <a href="dashboard.html">Dashboard</a>
            <a href="manage-pets.php">Manage Pets</a>
            <a href="applications.html">Applications</a>
            <a href="../index.html">Logout</a>
        </nav>

    </header>


    <!-- PAGE HEADING -->
    <section class="page-heading">

        <h1>Manage Pets 🐾</h1>

        <p>
            Add, update and manage pets available for adoption.
        </p>

    </section>


    <!-- MANAGE PETS -->
    <section class="manage-section">

        <div class="manage-top">

            <h2>Pet List</h2>

            <a href="../admin/add-pet.html" class="btn">
                + Add New Pet
            </a>

        </div>


        <!-- PET TABLE -->
        <div class="table-container">

            <table>

                <thead>

                    <tr>
                        <th>ID</th>
                        <th>Pet</th>
                        <th>Breed</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>

                </thead>

                <tbody>

                    <?php foreach ($pets as $pet) { ?>

                        <tr>

                            <td>
                                <?php echo $pet["id"]; ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($pet["name"]); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($pet["breed"]); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($pet["age"]); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($pet["gender"]); ?>
                            </td>

                            <td>

                                <?php if ($pet["status"] == "Available") { ?>

                                    <span class="pet-status available-status">
                                        Available
                                    </span>

                                <?php } elseif ($pet["status"] == "Adopted") { ?>

                                    <span class="pet-status adopted-status">
                                        Adopted
                                    </span>

                                <?php } else { ?>

                                    <span class="pet-status pending-status">
                                        <?php echo htmlspecialchars($pet["status"]); ?>
                                    </span>

                                <?php } ?>

                            </td>

                            <td>

                                <a href="edit-pet.php?id=<?php echo $pet["id"]; ?>"
                                   class="edit-btn">
                                    Edit
                                </a>

                                <a href="../php/delete-pet.php?id=<?php echo $pet["id"]; ?>"
                                class="delete-btn"
                                onclick="return confirm('Are you sure you want to delete this pet?');">
                                    Delete
                                </a>

                            </td>

                        </tr>

                    <?php } ?>

                    <?php if (count($pets) == 0) { ?>

                        <tr>

                            <td colspan="7">
                                No pets found.
                            </td>

                        </tr>

                    <?php } ?>

                </tbody>

            </table>

        </div>

    </section>


    <!-- FOOTER -->
    <footer>

        <h3>PawNest 🐾</h3>

        <p>Where Every Pet Finds a Home.</p>

        <p class="copyright">
            © 2026 PawNest. All Rights Reserved.
        </p>

    </footer>

</body>

</html>
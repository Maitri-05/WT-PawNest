<?php

echo "HELLO FROM CONNECTION TEST";

?>
<!-- <?php

require_once "db.php";


// Get pet ID from URL
$id = $_GET["id"];


// ================= UPDATE PET =================

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST["name"];
    $type = $_POST["type"];
    $breed = $_POST["breed"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $description = $_POST["description"];
    $image = $_POST["image"];
    $status = $_POST["status"];

    try {

        $sql = "UPDATE pets SET
                name = :name,
                type = :type,
                breed = :breed,
                age = :age,
                gender = :gender,
                description = :description,
                image = :image,
                status = :status
                WHERE id = :id";

        $stmt = $conn->prepare($sql);

        $stmt->execute([
            ":name" => $name,
            ":type" => $type,
            ":breed" => $breed,
            ":age" => $age,
            ":gender" => $gender,
            ":description" => $description,
            ":image" => $image,
            ":status" => $status,
            ":id" => $id
        ]);

        echo "Pet updated successfully!";

    } catch (PDOException $e) {

        die("Error updating pet: " . $e->getMessage());

    }

}


// ================= FETCH PET =================

try {

    $sql = "SELECT * FROM pets WHERE id = :id";

    $stmt = $conn->prepare($sql);

    $stmt->execute([
        ":id" => $id
    ]);

    $pet = $stmt->fetch(PDO::FETCH_ASSOC);


    if (!$pet) {

        die("Pet not found.");

    }

} catch (PDOException $e) {

    die("Error fetching pet: " . $e->getMessage());

}

?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/style.css">

    <title>Edit Pet - PawNest</title>

</head>

<body>


<header>

    <div class="logo">
        PawNest 🐾
    </div>

    <nav>
        <a href="manage-pets.php">Manage Pets</a>
        <a href="applications.html">Applications</a>
        <a href="../index.html">Logout</a>
    </nav>

</header>


<section class="page-heading">

    <h1>Edit Pet 🐾</h1>

    <p>
        Update the pet information below.
    </p>

</section>


<section class="form-section">

    <form method="POST" action="edit-pet.php?id=<?php echo $pet["id"]; ?>">

        <label>Pet Name</label>

        <input type="text"
               name="name"
               value="<?php echo htmlspecialchars($pet["name"]); ?>"
               required>


        <label>Pet Type</label>

        <input type="text"
               name="type"
               value="<?php echo htmlspecialchars($pet["type"]); ?>"
               required>


        <label>Breed</label>

        <input type="text"
               name="breed"
               value="<?php echo htmlspecialchars($pet["breed"]); ?>"
               required>


        <label>Age</label>

        <input type="text"
               name="age"
               value="<?php echo htmlspecialchars($pet["age"]); ?>"
               required>


        <label>Gender</label>

        <select name="gender" required>

            <option value="Male"
                <?php if ($pet["gender"] == "Male") echo "selected"; ?>>
                Male
            </option>

            <option value="Female"
                <?php if ($pet["gender"] == "Female") echo "selected"; ?>>
                Female
            </option>

        </select>


        <label>Description</label>

        <textarea name="description"
                  required><?php echo htmlspecialchars($pet["description"]); ?></textarea>


        <label>Image</label>

        <input type="text"
               name="image"
               value="<?php echo htmlspecialchars($pet["image"]); ?>">


        <label>Status</label>

        <select name="status" required>

            <option value="Available"
                <?php if ($pet["status"] == "Available") echo "selected"; ?>>
                Available
            </option>

            <option value="Pending"
                <?php if ($pet["status"] == "Pending") echo "selected"; ?>>
                Pending
            </option>

            <option value="Adopted"
                <?php if ($pet["status"] == "Adopted") echo "selected"; ?>>
                Adopted
            </option>

        </select>


        <button type="submit" class="btn">
            Update Pet
        </button>

    </form>

</section>


<footer>

    <h3>PawNest 🐾</h3>

    <p>Where Every Pet Finds a Home.</p>

    <p class="copyright">
        © 2026 PawNest. All Rights Reserved.
    </p>

</footer>


</body>

</html> -->


<?php

require_once "db.php";


// Get pet ID from URL
$id = $_GET["id"];


// ================= UPDATE PET =================

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST["name"];
    $type = $_POST["type"];
    $breed = $_POST["breed"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $description = $_POST["description"];
    $image = $_POST["image"];
    $status = $_POST["status"];

    try {

        $sql = "UPDATE pets SET
                name = :name,
                type = :type,
                breed = :breed,
                age = :age,
                gender = :gender,
                description = :description,
                image = :image,
                status = :status
                WHERE id = :id";

        $stmt = $conn->prepare($sql);

        $stmt->execute([
            ":name" => $name,
            ":type" => $type,
            ":breed" => $breed,
            ":age" => $age,
            ":gender" => $gender,
            ":description" => $description,
            ":image" => $image,
            ":status" => $status,
            ":id" => $id
        ]);

        // Redirect after successful update
        header("Location: manage-pets.php?message=updated");
        exit;

    } catch (PDOException $e) {

        die("Error updating pet: " . $e->getMessage());

    }

}


// ================= FETCH PET =================

try {

    $sql = "SELECT * FROM pets WHERE id = :id";

    $stmt = $conn->prepare($sql);

    $stmt->execute([
        ":id" => $id
    ]);

    $pet = $stmt->fetch(PDO::FETCH_ASSOC);


    if (!$pet) {

        die("Pet not found.");

    }

} catch (PDOException $e) {

    die("Error fetching pet: " . $e->getMessage());

}

?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/style.css">

    <title>Edit Pet - PawNest</title>

</head>

<body>


<header>

    <div class="logo">
        PawNest 🐾
    </div>

    <nav>
        <a href="manage-pets.php">Manage Pets</a>
        <a href="applications.html">Applications</a>
        <a href="../index.html">Logout</a>
    </nav>

</header>


<section class="admin-form-section">

    <h1>Edit Pet 🐾</h1>

    <p>
        Update the pet information below.
    </p>


    <form method="POST" action="edit-pet.php?id=<?php echo $pet["id"]; ?>">

        <label>Pet Name</label>

        <input type="text"
               name="name"
               value="<?php echo htmlspecialchars($pet["name"]); ?>"
               required>


        <label>Pet Type</label>

        <input type="text"
               name="type"
               value="<?php echo htmlspecialchars($pet["type"]); ?>"
               required>


        <label>Breed</label>

        <input type="text"
               name="breed"
               value="<?php echo htmlspecialchars($pet["breed"]); ?>"
               required>


        <label>Age</label>

        <input type="text"
               name="age"
               value="<?php echo htmlspecialchars($pet["age"]); ?>"
               required>


        <label>Gender</label>

        <select name="gender" required>

            <option value="Male"
                <?php if ($pet["gender"] == "Male") echo "selected"; ?>>
                Male
            </option>

            <option value="Female"
                <?php if ($pet["gender"] == "Female") echo "selected"; ?>>
                Female
            </option>

        </select>


        <label>Description</label>

        <textarea name="description" required><?php
            echo htmlspecialchars($pet["description"]);
        ?></textarea>


        <label>Image</label>

        <input type="text"
               name="image"
               value="<?php echo htmlspecialchars($pet["image"]); ?>">


        <label>Status</label>

        <select name="status" required>

            <option value="Available"
                <?php if ($pet["status"] == "Available") echo "selected"; ?>>
                Available
            </option>

            <option value="Pending"
                <?php if ($pet["status"] == "Pending") echo "selected"; ?>>
                Pending
            </option>

            <option value="Adopted"
                <?php if ($pet["status"] == "Adopted") echo "selected"; ?>>
                Adopted
            </option>

        </select>


        <button type="submit" class="btn">
            Update Pet
        </button>

    </form>

</section>


<footer>

    <h3>PawNest 🐾</h3>

    <p>Where Every Pet Finds a Home.</p>

    <p class="copyright">
        © 2026 PawNest. All Rights Reserved.
    </p>

</footer>


</body>

</html>
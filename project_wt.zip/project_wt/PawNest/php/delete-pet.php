<?php

require_once "db.php";

// Get pet ID
$id = $_GET["id"];

try {

    // Delete pet from database
    $sql = "DELETE FROM pets WHERE id = :id";

    $stmt = $conn->prepare($sql);

    $stmt->execute([
        ":id" => $id
    ]);

    // Go back to Manage Pets
    header("Location: manage-pets.php?deleted=1");
    exit;

} catch (PDOException $e) {

    die("Error deleting pet: " . $e->getMessage());

}

?>
<?php

require_once "db.php";


// Get form data
$name = $_POST["name"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$password = $_POST["password"];
$confirm_password = $_POST["confirm_password"];


// Check if passwords match
if ($password != $confirm_password) {

    die("Passwords do not match.");

}


try {

    // Check if an admin already exists
    $sql = "SELECT COUNT(*) FROM users WHERE role = 'admin'";

    $stmt = $conn->prepare($sql);
    $stmt->execute();

    $admin_count = $stmt->fetchColumn();


    if ($admin_count > 0) {

    die("Admin already exists. Cannot add another admin.");

    }


    // Check if email already exists
    $sql = "SELECT COUNT(*) FROM users WHERE email = :email";

    $stmt = $conn->prepare($sql);

    $stmt->execute([
        ":email" => $email
    ]);

    $email_count = $stmt->fetchColumn();


    if ($email_count > 0) {

        die("This email is already registered.");

    }


    // Encrypt password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);


    // Insert admin into users table
    $sql = "INSERT INTO users
            (name, email, phone, password, role)
            VALUES
            (:name, :email, :phone, :password, 'admin')";

    $stmt = $conn->prepare($sql);

    $stmt->execute([
        ":name" => $name,
        ":email" => $email,
        ":phone" => $phone,
        ":password" => $hashed_password
    ]);


    echo "Admin registered successfully!";

    echo "<br><br>";

    echo '<a href="../admin/admin-login.html">Go to Admin Login</a>';


} catch (PDOException $e) {

    die("Error during admin registration: " . $e->getMessage());

}

?>
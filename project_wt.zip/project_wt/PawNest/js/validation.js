// ==================================================
// PAWNEST - FORM VALIDATION
// ==================================================


// ================= REGISTER FORM =================


function validateRegister() {

    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let phone = document.getElementById("phone").value.trim();
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirm-password").value;


    // Full name validation
    if (name === "") {
        alert("Please enter your full name.");
        return false;
    }


    // Email validation
    let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }


    // Phone validation
    let phonePattern = /^[0-9]{10}$/;

    if (!phonePattern.test(phone)) {
        alert("Please enter a valid 10-digit phone number.");
        return false;
    }


    // Password validation
    if (password.length < 6) {
        alert("Password must contain at least 6 characters.");
        return false;
    }


    // Confirm password validation
    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }


    // If everything is valid
    alert("Registration successful!");

    return false;
}



// ================= LOGIN FORM =================

function validateLogin() {

    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value;


    // Email validation
    let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }


    // Password validation
    if (password === "") {
        alert("Please enter your password.");
        return false;
    }


    alert("Login validation successful!");

    return false;
}


// ================= ADOPTION FORM =================

function validateAdoption() {

    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let phone = document.getElementById("phone").value.trim();
    let address = document.getElementById("address").value.trim();
    let reason = document.getElementById("reason").value.trim();


    // Full name validation
    if (name === "") {
        alert("Please enter your full name.");
        return false;
    }


    // Email validation
    let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }


    // Phone validation
    let phonePattern = /^[0-9]{10}$/;

    if (!phonePattern.test(phone)) {
        alert("Please enter a valid 10-digit phone number.");
        return false;
    }


    // Address validation
    if (address === "") {
        alert("Please enter your address.");
        return false;
    }


    // Pet experience validation
    let experience = document.querySelector(
        'input[name="experience"]:checked'
    );

    if (experience === null) {
        alert("Please select whether you have experience with pets.");
        return false;
    }


    // Adoption reason validation
    if (reason.length < 10) {
        alert("Please provide a proper reason for adoption.");
        return false;
    }


    // Validation successful
    alert("Application validation successful!");

    // Stop submission for now because PHP is not connected yet
    return false;
}